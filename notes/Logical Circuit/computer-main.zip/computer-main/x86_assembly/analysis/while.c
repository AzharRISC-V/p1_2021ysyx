
int main()
{
    int sum = 0;
    int count = 10;
    while (count --)
    {
        sum += count;
    }
}