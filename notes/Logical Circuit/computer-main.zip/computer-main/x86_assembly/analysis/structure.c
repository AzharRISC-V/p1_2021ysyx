
// typedef struct struct_t
// {
//     char c1;
//     int i1;
//     char c2;
//     int i2;
//     char c3;
//     int i3;
// } struct_t;

// typedef struct struct_t
// {
//     int i1;
//     int i2;
//     int i3;

//     char c1;
//     char c2;
//     char c3;
// } struct_t;

// struct_t data;

typedef enum enum_t
{
    ENUM1 = 1,
    ENUM2,
    ENUM3
} enum_t;

enum_t edata = 345;