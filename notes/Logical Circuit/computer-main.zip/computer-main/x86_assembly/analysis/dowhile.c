
int main()
{
    int sum = 0;
    int count = 10;
    do
    {
        sum += count;
    } while (count--);
}