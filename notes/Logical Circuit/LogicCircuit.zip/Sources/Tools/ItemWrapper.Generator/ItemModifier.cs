﻿using System;

namespace ItemWrapper.Generator {
	public enum ItemModifier {
		None,
		Abstract
	}
}
