﻿using System;

namespace LogicCircuit {
	public enum ColorPickerMode {
		Color,
		Foreground,
		Background
	}
}
