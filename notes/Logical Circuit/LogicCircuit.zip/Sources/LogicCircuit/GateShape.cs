﻿using System;

namespace LogicCircuit {
	public enum GateShape {
		Rectangular,
		Shaped
	}
}
