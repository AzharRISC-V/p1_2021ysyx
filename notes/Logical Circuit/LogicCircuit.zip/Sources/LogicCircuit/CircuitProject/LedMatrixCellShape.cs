﻿using System;

namespace LogicCircuit {
	public enum LedMatrixCellShape {
		Round,
		Rectangle
	}
}
