# LogicCircuit
**LogicCircuit** – is free, open source educational software for designing and simulating digital logic circuits.
![LogicCircuit](https://logiccircuit.org/images/screenshot.png)

### How do I build it ###

* Use Visual Studio.
* Install Wix Toolset extension
