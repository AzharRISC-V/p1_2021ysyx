﻿using System;

namespace LogicCircuit {
	public enum PinType {
		None,
		Input,
		Output
	}
}
