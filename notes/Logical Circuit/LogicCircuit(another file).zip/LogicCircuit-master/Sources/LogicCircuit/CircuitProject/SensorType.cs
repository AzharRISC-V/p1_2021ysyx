﻿using System;

namespace LogicCircuit {
	public enum SensorType {
		Series,
		Loop,
		Random,
		Manual
	}
}
