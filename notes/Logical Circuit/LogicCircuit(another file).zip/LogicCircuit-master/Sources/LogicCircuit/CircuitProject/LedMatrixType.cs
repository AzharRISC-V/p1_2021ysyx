﻿using System;

namespace LogicCircuit {
	public enum LedMatrixType {
		Individual,
		Selector
	}
}
