﻿using System;

namespace LogicCircuit {
	[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1028:EnumStorageShouldBeInt32")]
	public enum State : byte {
		Off,
		On0,
		On1
	}
}
