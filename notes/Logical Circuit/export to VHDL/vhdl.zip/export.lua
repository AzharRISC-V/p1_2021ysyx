require("libs/base")
require("libs/meta")
require("libs/lists")
require("libs/advstring")
require("libs/class")
--require("libs/serialize")
require("libs/vector")

local fname,outfolder=...
outfolder=outfolder or ""
local lstr,err=io.open(fname or "test.CircuitProject","r")
if not lstr then
	error(err)
end
lstr=lstr:read("*a")

local data={}
print("splitting tags")
lstr:gsub("(%<.-%>)([^%<]*)",function(a,b)
	table.insert(data,a)
	b=b:strip()
	if b~="" then
		table.insert(data,b)
	end
	return nil
end)
local treeify
treeify=function(data,i,parent,level)
	level=level or 0
	local me={tag=parent}
	if me.tag:sub(1,3)=="lc:" then
		me.tag=me.tag:sub(4,-1)
	end
	while i<=#data do
		--serialize.prettyprint(me)
		if data[i]:sub(1,2)=="</" then--closing
			local entry = data[i]:sub(3,-2)
			if entry==parent then
				return i+1,me
			end
		elseif data[i]:sub(1,1)=="<" then
			local sub
			i,sub=treeify(data,i+1,data[i]:sub(2,-2),level+1)
			table.insert(me,sub)
		else
			table.insert(me,data[i])
			i=i+1
		end
		if i>=#data then break end
	end
	return i+1,me
end
local G=function(data)
	local _,toreturn=treeify(data,1,"",0)
	return toreturn[1]
end
--print("========")
--io.open("circuit_raw.srzp","w"):write(serialize.prettyencode(data))
print("treeifying xml data")
local k=G(data)
local heap={}
print("sorting by component type")
for k,v in ipairs(k[1]) do
	v.tag=v.tag:lower()
	heap[v.tag]=heap[v.tag] or {}
	table.insert(heap[v.tag],v)
end
local uuid=class{"uuid",
	constructor=function(str)return{str=str}end;
	unserialize=function(str)return{str=str}end;
	variables={str=""};
	serialize=function(self)return self.str end;
	metatable={
		__eq=function(a,b)
			return a.str==b.str
		end;
	};
}
local keays={"textnote","sensor","graphicsarray","logicalcircuit","circuitbutton","splitter","circuitprobe","project","constant","circuitsymbol","wire","ledmatrix","collapsedcategory","memory","pin"}
local C={}
for _,type in ipairs(keays) do
	C[type]=hollow_class(type)
end
local gate=hollow_class"gate"
local builtin=hollow_class"builtin"
local circuitproxy=hollow_class"circuitproxy"
print("making tags lowercase")
for T,list in pairs(heap) do
	for num,item in ipairs(list) do
		for key,entry in ipairs(item) do
			item[entry.tag:lower()]=entry[1]
			item[key]=nil
		end
	end
end

local map={}
local components_by_id={
	["00000000-0000-0000-0000-0000000b0200"]=builtin{name="TRILEFT",pins=1};
	["00000000-0000-0000-0000-0000000a0200"]=builtin{name="TRIRIGHT",pins=1};

	["00000000-0000-0000-0000-000000010000"]=builtin{name="clock",pins=1};
	["00000000-0000-0000-0000-000000080800"]=builtin{name="7-segment",pins=8};

	["00000000-0000-0000-0000-000000020101"]=gate{name="NOT",pins=1};
	["00000000-0000-0000-0000-000000030200"]=gate{name="OR",pins=2};
	["00000000-0000-0000-0000-000000030300"]=gate{name="OR",pins=3};
	["00000000-0000-0000-0000-000000030400"]=gate{name="OR",pins=4};
	["00000000-0000-0000-0000-000000030500"]=gate{name="OR",pins=5};
	["00000000-0000-0000-0000-000000030600"]=gate{name="OR",pins=6};
	["00000000-0000-0000-0000-000000030700"]=gate{name="OR",pins=7};
	["00000000-0000-0000-0000-000000030800"]=gate{name="OR",pins=8};
	["00000000-0000-0000-0000-000000030900"]=gate{name="OR",pins=9};
	["00000000-0000-0000-0000-000000030a00"]=gate{name="OR",pins=10};
	["00000000-0000-0000-0000-000000030b00"]=gate{name="OR",pins=11};
	["00000000-0000-0000-0000-000000030c00"]=gate{name="OR",pins=12};
	["00000000-0000-0000-0000-000000030d00"]=gate{name="OR",pins=13};
	["00000000-0000-0000-0000-000000030e00"]=gate{name="OR",pins=14};
	["00000000-0000-0000-0000-000000030f00"]=gate{name="OR",pins=15};
	["00000000-0000-0000-0000-000000031000"]=gate{name="OR",pins=16};
	["00000000-0000-0000-0000-000000031100"]=gate{name="OR",pins=17};
	["00000000-0000-0000-0000-000000031200"]=gate{name="OR",pins=18};

	["00000000-0000-0000-0000-000000030201"]=gate{name="NOR",pins=2};
	["00000000-0000-0000-0000-000000030301"]=gate{name="NOR",pins=3};
	["00000000-0000-0000-0000-000000030401"]=gate{name="NOR",pins=4};
	["00000000-0000-0000-0000-000000030501"]=gate{name="NOR",pins=5};
	["00000000-0000-0000-0000-000000030601"]=gate{name="NOR",pins=6};
	["00000000-0000-0000-0000-000000030701"]=gate{name="NOR",pins=7};
	["00000000-0000-0000-0000-000000030801"]=gate{name="NOR",pins=8};
	["00000000-0000-0000-0000-000000030901"]=gate{name="NOR",pins=9};
	["00000000-0000-0000-0000-000000030a01"]=gate{name="NOR",pins=10};
	["00000000-0000-0000-0000-000000030b01"]=gate{name="NOR",pins=11};
	["00000000-0000-0000-0000-000000030c01"]=gate{name="NOR",pins=12};
	["00000000-0000-0000-0000-000000030d01"]=gate{name="NOR",pins=13};
	["00000000-0000-0000-0000-000000030e01"]=gate{name="NOR",pins=14};
	["00000000-0000-0000-0000-000000030f01"]=gate{name="NOR",pins=15};
	["00000000-0000-0000-0000-000000031001"]=gate{name="NOR",pins=16};
	["00000000-0000-0000-0000-000000031101"]=gate{name="NOR",pins=17};
	["00000000-0000-0000-0000-000000031201"]=gate{name="NOR",pins=18};

	["00000000-0000-0000-0000-000000040200"]=gate{name="AND",pins=2};
	["00000000-0000-0000-0000-000000040300"]=gate{name="AND",pins=3};
	["00000000-0000-0000-0000-000000040400"]=gate{name="AND",pins=4};
	["00000000-0000-0000-0000-000000040500"]=gate{name="AND",pins=5};
	["00000000-0000-0000-0000-000000040600"]=gate{name="AND",pins=6};
	["00000000-0000-0000-0000-000000040700"]=gate{name="AND",pins=7};
	["00000000-0000-0000-0000-000000040800"]=gate{name="AND",pins=8};
	["00000000-0000-0000-0000-000000040900"]=gate{name="AND",pins=9};
	["00000000-0000-0000-0000-000000040a00"]=gate{name="AND",pins=10};
	["00000000-0000-0000-0000-000000040b00"]=gate{name="AND",pins=11};
	["00000000-0000-0000-0000-000000040c00"]=gate{name="AND",pins=12};
	["00000000-0000-0000-0000-000000040d00"]=gate{name="AND",pins=13};
	["00000000-0000-0000-0000-000000040e00"]=gate{name="AND",pins=14};
	["00000000-0000-0000-0000-000000040f00"]=gate{name="AND",pins=15};
	["00000000-0000-0000-0000-000000041000"]=gate{name="AND",pins=16};
	["00000000-0000-0000-0000-000000041100"]=gate{name="AND",pins=17};
	["00000000-0000-0000-0000-000000041200"]=gate{name="AND",pins=18};

	["00000000-0000-0000-0000-000000040201"]=gate{name="NAND",pins=2};
	["00000000-0000-0000-0000-000000040301"]=gate{name="NAND",pins=3};
	["00000000-0000-0000-0000-000000040401"]=gate{name="NAND",pins=4};
	["00000000-0000-0000-0000-000000040501"]=gate{name="NAND",pins=5};
	["00000000-0000-0000-0000-000000040601"]=gate{name="NAND",pins=6};
	["00000000-0000-0000-0000-000000040701"]=gate{name="NAND",pins=7};
	["00000000-0000-0000-0000-000000040801"]=gate{name="NAND",pins=8};
	["00000000-0000-0000-0000-000000040901"]=gate{name="NAND",pins=9};
	["00000000-0000-0000-0000-000000040a01"]=gate{name="NAND",pins=10};
	["00000000-0000-0000-0000-000000040b01"]=gate{name="NAND",pins=11};
	["00000000-0000-0000-0000-000000040c01"]=gate{name="NAND",pins=12};
	["00000000-0000-0000-0000-000000040d01"]=gate{name="NAND",pins=13};
	["00000000-0000-0000-0000-000000040e01"]=gate{name="NAND",pins=14};
	["00000000-0000-0000-0000-000000040f01"]=gate{name="NAND",pins=15};
	["00000000-0000-0000-0000-000000041001"]=gate{name="NAND",pins=16};
	["00000000-0000-0000-0000-000000041101"]=gate{name="NAND",pins=17};
	["00000000-0000-0000-0000-000000041201"]=gate{name="NAND",pins=18};

	["00000000-0000-0000-0000-000000050200"]=gate{name="XOR",pins=2};
	["00000000-0000-0000-0000-000000050300"]=gate{name="XOR",pins=3};
	["00000000-0000-0000-0000-000000050400"]=gate{name="XOR",pins=4};
	["00000000-0000-0000-0000-000000050500"]=gate{name="XOR",pins=5};
	["00000000-0000-0000-0000-000000050600"]=gate{name="XOR",pins=6};
	["00000000-0000-0000-0000-000000050700"]=gate{name="XOR",pins=7};
	["00000000-0000-0000-0000-000000050800"]=gate{name="XOR",pins=8};
	["00000000-0000-0000-0000-000000050900"]=gate{name="XOR",pins=9};
	["00000000-0000-0000-0000-000000050a00"]=gate{name="XOR",pins=10};
	["00000000-0000-0000-0000-000000050b00"]=gate{name="XOR",pins=11};
	["00000000-0000-0000-0000-000000050c00"]=gate{name="XOR",pins=12};
	["00000000-0000-0000-0000-000000050d00"]=gate{name="XOR",pins=13};
	["00000000-0000-0000-0000-000000050e00"]=gate{name="XOR",pins=14};
	["00000000-0000-0000-0000-000000050f00"]=gate{name="XOR",pins=15};
	["00000000-0000-0000-0000-000000051000"]=gate{name="XOR",pins=16};
	["00000000-0000-0000-0000-000000051100"]=gate{name="XOR",pins=17};
	["00000000-0000-0000-0000-000000051200"]=gate{name="XOR",pins=18};

	["00000000-0000-0000-0000-000000050201"]=gate{name="XNOR",pins=2};
	["00000000-0000-0000-0000-000000050301"]=gate{name="XNOR",pins=3};
	["00000000-0000-0000-0000-000000050401"]=gate{name="XNOR",pins=4};
	["00000000-0000-0000-0000-000000050501"]=gate{name="XNOR",pins=5};
	["00000000-0000-0000-0000-000000050601"]=gate{name="XNOR",pins=6};
	["00000000-0000-0000-0000-000000050701"]=gate{name="XNOR",pins=7};
	["00000000-0000-0000-0000-000000050801"]=gate{name="XNOR",pins=8};
	["00000000-0000-0000-0000-000000050901"]=gate{name="XNOR",pins=9};
	["00000000-0000-0000-0000-000000050a01"]=gate{name="XNOR",pins=10};
	["00000000-0000-0000-0000-000000050b01"]=gate{name="XNOR",pins=11};
	["00000000-0000-0000-0000-000000050c01"]=gate{name="XNOR",pins=12};
	["00000000-0000-0000-0000-000000050d01"]=gate{name="XNOR",pins=13};
	["00000000-0000-0000-0000-000000050e01"]=gate{name="XNOR",pins=14};
	["00000000-0000-0000-0000-000000050f01"]=gate{name="XNOR",pins=15};
	["00000000-0000-0000-0000-000000051001"]=gate{name="XNOR",pins=16};
	["00000000-0000-0000-0000-000000051101"]=gate{name="XNOR",pins=17};
	["00000000-0000-0000-0000-000000051201"]=gate{name="XNOR",pins=18};
}
local findCircuit=function(uuid)
	--serialize.prettyprint(uuid)
	for i,c in pairs(heap.logicalcircuit) do
		--print(c.id,uuid,c.id==uuid)
		if c.id==uuid then
			return i
		end
	end
end

local insert_component=function(component)
	local i=findCircuit(component.logicalcircuitid)
	if not i then return end
	heap.logicalcircuit[i].components[classType(component)]=heap.logicalcircuit[i].components[classType(component)] or {}
	table.insert(heap.logicalcircuit[i].components[classType(component)],component)
end

local rotate=function(point,center,rotation)
	local rotationCount=({
		up=4,
		right=1,
		down=2,
		left=3,
	})[rotation or "up"]
	local torotate=(point-center)
	for i=1,rotationCount do
		torotate=vector(-torotate.y,torotate.x)
	end
	return (center+torotate):floor()
end


local comp=function(a,b)
	if a.pos.y<b.pos.y then
		return true
	elseif a.pos.x<b.pos.x then
		return true
	else
		return false
	end
end
local insertion_sort=function(list)
	local new={list[#list]}
	for i=#list-1,1,-1 do
		local v=list[i]
		local inserted=false
		for k=1,#new do
			if not comp(new[k],v) then
				table.insert(new,k,v)
				inserted=true
				break
			end
		end
		if not inserted then
			table.insert(new,v)
		end
	end
	return new
end

local place_pins_simple=function(pincount,size)
	-- 1 pin  =center rounded down
	-- 2 pins =either end
	-- 3 pins =either end + middle rounded down
	-- >3 pins= for i=2,size-1,size/count
	if pincount<=0 then
		return {}
	elseif pincount==1 then
		return {math.floor(size/2)}
	elseif pincount==2 then
		return {1,size-1}
	elseif pincount==3 then
		return {1,math.floor(size/2),size-1}
	else
		local list={}
		local step=math.floor((size)/pincount)
		local pos=1
		for i=1,pincount do
			table.insert(list,pos)
			pos=pos+step
		end
		return list
	end
end

local place_pins=function(pins,rotation,size,abs_pos,minsize)
	minsize=minsize or vector(2,3)
	size=size or vector(
		max{#pins.top,#pins.bottom,minsize.x}+1,
		max{#pins.right,#pins.left,minsize.y}+1
	)
	abs_pos=abs_pos or vector(0,0)
	local sidemap={
		top=	function(vec)return vec.x end;
		bottom=	function(vec)return vec.x end;
		right=	function(vec)return vec.y end;
		left=	function(vec)return vec.y end;
	}
	local pointmap={
		top=	function(pos,size)return vector(pos,0) end;
		bottom=	function(pos,size)return vector(pos,size.y) end;
		right=	function(pos,size)return vector(size.x,pos) end;
		left=	function(pos,size)return vector(0,pos) end;
	}

	local center=size/2
	if size.x%2~=1 or size.y%2~=1 then
		center=center:floor()
	end

	local allpins={}
	for side,pins in pairs(pins) do
		for pin,pos in ipairs(place_pins_simple(#pins,sidemap[side](size))) do
			pins[pin].connectionpoint=pointmap[side](pos,size)
			table.insert(allpins,class"pin"{
				field=pins[pin].field;
				net=false;
				name=pins[pin].name,
				pos=rotate(pins[pin].connectionpoint,center,rotation)+abs_pos;
				bitwidth=pins[pin].bitwidth;
			})
		end
	end

	return allpins
end

print("cleaning components")

print("\tcleaning logicalcircuits")
for i,m in ipairs(heap.logicalcircuit or {}) do
	heap.logicalcircuit[i]=C.logicalcircuit{
		category=m.category or "",
		isdisplay=m.isdisplay=="True",
		id=uuid(m.logicalcircuitid),
		name=m.name or "",
		notation=m.notation or "",
		note=m.note or "",
		components={},
	}
	components_by_id[heap.logicalcircuit[i].id.str]=circuitproxy{id=heap.logicalcircuit[i].id}
end
print("\tcleaning wires")
for i,w in ipairs(heap.wire or {}) do
	heap.wire[i]=C.wire{
		wireid=uuid(w.wireid),
		logicalcircuitid=uuid(w.logicalcircuitid),
		start=vector(tonumber(w.x1 or 0),tonumber(w.y1 or 0)),
		stop =vector(tonumber(w.x2 or 0),tonumber(w.y2 or 0)),
	}
	insert_component(heap.wire[i])
end
print("\tcleaning memorys")
for i,m in ipairs(heap.memory or {}) do
	--serialize.prettyprint(m)
	heap.memory[i]=C.memory{
		addressbitwidth=tonumber(m.addressbitwidth),
		databitwidth=tonumber(m.databitwidth),
		id=uuid(m.memoryid),
		data=(m.data or ""):gsub("%s",""):frombase64(),
		onstart=({Random="random",Ones="ones",Data="persistant"})[m.onstart]or "zeros",
		writeable=(m.writable or ""):lower()=="true",
		edge=IF(m.writeon1=="True","rising","falling"),
	}
	components_by_id[heap.memory[i].id.str]=heap.memory[i]
	insert_component(heap.memory[i])
end
print("\tcleaning constants")
for i,m in ipairs(heap.constant or {}) do
	heap.constant[i]=C.constant{
		bitwidth=tonumber(m.bitwidth or 1),
		id=uuid(m.constantid),
		pinside=(m.pinside or "Right"):lower(),
		value=tonumber(m.value or 0),
	}
	components_by_id[heap.constant[i].id.str]=heap.constant[i]
	insert_component(heap.constant[i])
end
print("\tcleaning splitters")
for i,m in ipairs(heap.splitter or {}) do
	heap.splitter[i]=C.splitter{
		bitwidth=tonumber(m.bitwidth or 1),
		clockwise=m.clockwise=="True",
		pincount=tonumber(m.pincount or 2),
		id=uuid(m.splitterid),
	}
	components_by_id[heap.splitter[i].id.str]=heap.splitter[i]
	insert_component(heap.splitter[i])
end
print("\tcleaning pins")
for i,m in ipairs(heap.pin or {}) do
	heap.pin[i]=C.pin{
		bitwidth=tonumber(m.bitwidth or 1),
		name=m.name or "",
		node=m.note or "",
		logicalcircuitid=uuid(m.circuitid),
		jamnotation=m.jamnotation or "",
		pinside=(m.pinside or "left"):lower(),
		pintype=(m.pintype or "input"):lower(),
		id=uuid(m.pinid),
	}
	components_by_id[heap.pin[i].id.str]=heap.pin[i]
	insert_component(heap.pin[i])
end
print("\tcleaning circuitsymbols")
for i,m in ipairs(heap.circuitsymbol or {}) do
	heap.circuitsymbol[i]=C.circuitsymbol{
		circuitid=uuid(m.circuitid),
		id=uuid(m.circuitsymbolid),
		pos=vector(tonumber(m.x or 0),tonumber(m.y or 0)),
		rotation=(m.rotation or "up"):lower(),
		logicalcircuitid=uuid(m.logicalcircuitid),
	}
	components_by_id[heap.circuitsymbol[i].id.str]=heap.circuitsymbol[i]
	insert_component(heap.circuitsymbol[i])
end
print("\tcleaning circuitbuttons")
for i,m in ipairs(heap.circuitbutton or {}) do
	heap.circuitbutton[i]=C.circuitbutton{
		pinside=(m.pinside or "right"):lower(),
		size=vector(tonumber(m.width or 3),tonumber(m.height or 3)),
		istoggle=m.istoggle=="True",
		notation=m.notation or "",
		id=uuid(m.circuitbuttonid),
	}
	components_by_id[heap.circuitbutton[i].id.str]=heap.circuitbutton[i]
	insert_component(heap.circuitbutton[i])
end
print("\tcleaning circuitprobes")
for i,m in ipairs(heap.circuitprobe or {}) do
	heap.circuitprobe[i]=C.circuitprobe{
		id=uuid(m.circuitprobeid),
		name=m.name or "",
	}
	components_by_id[heap.circuitprobe[i].id.str]=heap.circuitprobe[i]
	insert_component(heap.circuitprobe[i])
end
print("\tcleaning sensors")
for i,m in ipairs(heap.sensor or {}) do
	heap.sensor[i]=C.sensor{
		id=uuid(m.sensorid),
		name=m.name or "",
		data=m.data or "",
		pinside=(m.pinside or "Right"):lower(),
		bitwidth=tonumber(m.bitwidth or 1),
		type=(m.sensortype or "Random"):lower(),
	}
	components_by_id[heap.sensor[i].id.str]=heap.sensor[i]
	insert_component(heap.sensor[i])
end
print("\tcleaning graphicsarrays")
for i,m in ipairs(heap.graphicsarray or {}) do
	heap.graphicsarray[i]=C.graphicsarray{
		id=uuid(m.graphicsarrayid),
		size=vector(tonumber(m.width or 0),tonumber(m.height or 0)),
		onstart=({Random="random",Ones="ones"})[m.onstart]or "zeros",
		bitsperpixel=tonumber(m.bitsperpixel or 1),
		databitwidth=tonumber(m.databitwidth or 1),
	}
	components_by_id[heap.graphicsarray[i].id.str]=heap.graphicsarray[i]
	insert_component(heap.graphicsarray[i])
end
print("\tcleaning ledmatrixs")
for i,m in ipairs(heap.ledmatrix or {}) do
	heap.ledmatrix[i]=C.ledmatrix{
		id=uuid(m.ledmatrixid),
		size=vector(tonumber(m.columns or 1),tonumber(m.rows or 1)),
		cellshape=(m.cellshape or "Circular"):lower(),
		colors=tonumber(m.colors or 2),
	}
	components_by_id[heap.ledmatrix[i].id.str]=heap.ledmatrix[i]
	insert_component(heap.ledmatrix[i])
end

print("linking circuitsymbols with components")
--linking circuitsymbols with circuits
for i,m in ipairs(heap.circuitsymbol or {}) do
	m.component=components_by_id[m.circuitid.str]
	--if not m.component then
	--	serialize.prettyprint(m)
	--end
end


--extracting nets

local DFS,DFS_visit
DFS=function(connections,colormap)
	local latestNet=1
	local netmap={}
	for net,neighbours in pairs(connections) do
		if colormap[net]=="white" then
			DFS_visit(net,connections,colormap,netmap,latestNet)
			latestNet=latestNet+1
		end
	end
	return netmap
end
DFS_visit=function(net,connections,colormap,netmap,latestNet)
	colormap[net]="gray"
	netmap[net]=latestNet
	for _,neighbour in ipairs(connections[net]) do
		if colormap[neighbour]=="white" then
			DFS_visit(neighbour,connections,colormap,netmap,latestNet)
		end
	end
	colormap[net]="black"
end
print("mapping nets in circuits")
for _,c in ipairs(heap.logicalcircuit) do--extracting nets
	local connections={}
	local colormap={}
	local nets={}
	local wiremap={}
	for i,wire in ipairs(c.components.wire or {}) do
		local a,b=tostring(wire.start),tostring(wire.stop)
		wiremap[a]=wire.start
		wiremap[b]=wire.stop
		colormap[a]="white"
		connections[a]=connections[a] or {}
		--if not isIn(connections[a],b) then
			table.insert(connections[a],b)
		--end
		colormap[b]="white"
		connections[b]=connections[b] or {}
		--if not isIn(connections[b],a) then
			table.insert(connections[b],a)
		--end
	end
	local netmap=DFS(connections,colormap)
	local nets={}
	for node,net in pairs(netmap) do
		local pos=wiremap[node]
		nets[net]=nets[net] or {}
		table.insert(nets[net],pos)
	end
	c.nets=nets
	--c["_"]={connections=connections,colormap=colormap,netmap=netmap,nets=nets,wiremap=wiremap}
	c.components.wire=nil
end

--mapping pins to nets

local connection_offsets={
	up=vector(2,1),
	right=vector(1,2),
	down=vector(0,1),
	left=vector(1,0),
}
local offsetNum={
	["up"]		=0,
	[0]			="up",
	["right"]	=1,
	[1]			="right",
	["down"]	=2,
	[2]			="down",
	["left"]	=3,
	[3]			="left",
}
local findNet=function(pos,nets)
	for net,points in ipairs(nets) do
		if isIn(points,pos) then
			return net
		end
	end
	return -1
end
print("connecting pins to nets")
for _,c in ipairs(heap.logicalcircuit) do
	c.input={}
	c.output={}
	for i,pin in ipairs(c.components.pin or {}) do
		if pin.pintype=="input" then
			table.insert(c.input,pin)
		else
			table.insert(c.output,pin)
		end
	end
	local toremove={}
	for i,sym in ipairs(c.components.circuitsymbol or {}) do
		if classType(sym.component)=="pin" then
			sym.component.connectionpoint=sym.pos+connection_offsets[offsetNum[(offsetNum[sym.rotation]+(IF(sym.component.pintype=="output",2,0)))%4]]
			sym.component.net=findNet(sym.component.connectionpoint,c.nets)
			--serialize.prettyprint(sym.component)
			if sym.component.net>=0 then
				c.nets[sym.component.net].bitwidth=c.nets[sym.component.net].bitwidth or {}
				table.insert(c.nets[sym.component.net].bitwidth,sym.component.bitwidth)
			end
			sym.component.absolute_pos=sym.pos
			table.insert(toremove,i)
		end
	end
	table.sort(toremove)
	for i=#toremove,1,-1 do
		table.remove(c.components.circuitsymbol or {},toremove[i])
	end
	c.components.pin=nil
end
print("sorting circuits by uuid")
local circuits_by_id={}
for _,circuit in ipairs(heap.logicalcircuit) do
	circuits_by_id[circuit.id.str]=circuit
end

--handle_splitters
--print("handling splitters")
-- for uuid,c in pairs(circuits_by_id) do
-- 	local toremove={}
-- 	local splitters={}
-- 	for i,sym in ipairs(c.components.circuitsymbol or {}) do
-- 		if classType(sym.component)=="splitter" then
-- 			table.insert(toremove,i)
-- 			sym.component.pos=sym.pos
-- 			sym.component.rotation=sym.rotation
-- 			--table.insert(splitters,sym.component)
-- 		end
-- 	end
-- 	--c.splitters=splitters
-- end

print("updating circuitproxies to enable connection to nets")
for uuid,circuit in pairs(circuits_by_id) do
	for i,sym in ipairs(circuit.components.circuitsymbol or {}) do
		local pins={
			top={};
			bottom={};
			left={};
			right={};
		}
		local allpins={}
		local dorest=false
		if classType(sym.component)=="circuitproxy" then
			local P=circuits_by_id[sym.component.id.str]
			sym.isdisplay=sym.component.isdisplay
			if not sym.isdisplay then
				dorest=true
				for i,pin in ipairs(P.input) do
					table.insert(pins[pin.pinside],{
						--connectionpoint=pin.connectionpoint,
						bitwidth=pin.bitwidth,
						pos=pin.absolute_pos,
						name=pin.name,
						field={"input",i},
					})
				end
				for i,pin in ipairs(P.output) do
					table.insert(pins[pin.pinside],{
						bitwidth=pin.bitwidth,
						name=pin.name,
						pos=pin.absolute_pos,
						field={"output",i},
					})
				end
				for side,pinside in pairs(pins) do
					pins[side]=insertion_sort(pinside)
				end
				sym.size=vector(
					max{#pins.top,#pins.bottom,2}+1,
					max{#pins.right,#pins.left,3}+1
				)
			end
		elseif classType(sym.component)=="gate" then
			dorest=true
			for i=1,sym.component.pins do
				table.insert(pins.left,{
					bitwidth=1,
					name="in_"..tostring(i),
					pos=vector(0,i),
					field={"input",i},
				})
			end
			table.insert(pins.right,{
				bitwidth=1,
				pos=vector(1,0),
				name="out_1",
				field={"output",1},
			})
			sym.size=vector(
				max{#pins.top,#pins.bottom,2}+1,
				max{#pins.right,#pins.left,3}+1
			)
		elseif classType(sym.component)=="memory" then
			dorest=true
		
			table.insert(pins.left,{
				bitwidth=sym.component.addressbitwidth,
				name="address",
				pos=vector(0,1),
				field={"input","address"},
			})
			table.insert(pins.right,{
				bitwidth=sym.component.databitwidth,
				name="data_out",
				pos=vector(0,1),
				field={"ouput","data"},
			})
			if sym.component.writeable then
				table.insert(pins.left,{
					bitwidth=sym.component.databitwidth,
					pos=vector(1,0),
					name="data_in",
					field={"input","data"},
				})
				table.insert(pins.bottom,{
					bitwidth=1,
					pos=vector(1,0),
					name="write",
					field={"input","data"},
				})
			end
			sym.size=vector(
				max{#pins.top,#pins.bottom,2}+1,
				max{#pins.right,#pins.left,3}+1
			)
		elseif classType(sym.component)=="splitter" then
			dorest=true
			if sym.component.clockwise then
				for i=1,sym.component.pincount do
					table.insert(pins.right,{
						bitwidth=math.floor(sym.component.bitwidth/sym.component.pincount),
						pos=vector(0,i),
						name="in_"..tostring(i),
						field={"input",i},
					})
				end
				table.insert(pins.left,{
					bitwidth=sym.component.bitwidth,
					pos=vector(1,0),
					name="out_1",
					field={"output",1},
				})
			else
				for i=1,sym.component.pincount do
					table.insert(pins.left,{
						bitwidth=math.floor(sym.component.bitwidth/sym.component.pincount),
						pos=vector(0,i),
						name="in_"..tostring(i),
						field={"input",i},
					})
				end
				table.insert(pins.right,{
					bitwidth=sym.component.bitwidth,
					pos=vector(1,0),
					name="out_1",
					field={"output",1},
				})
			end
			sym.size=vector(
				1,
				max{#pins.right,#pins.left,2}+1
			)
		end
		if dorest then
			allpins=place_pins(pins,sym.rotation,sym.size,sym.pos)
			--map nets


			for _,pin in ipairs(allpins) do
				pin.net=findNet(pin.pos,circuit.nets)
				--print(pin.net,pin.bitwidth)
				if pin.net>=0 then
					circuit.nets[pin.net].bitwidth=circuit.nets[pin.net].bitwidth or {}
					table.insert(circuit.nets[pin.net].bitwidth,pin.bitwidth)
				end
			end
			--serialize.prettyprint(allpins)
			sym.pins=allpins

		end
	end
end

print("generating headers")
local taken_names={}
local headers={}
local reserved_words={"","abs","access","after","alias","all",
	"and","case","exit","in","mod","or","record","sla","units",
	"architecture","component","file","inertial","nand","others","register","sli","until",
	"array","configuration","for","inout","new","out","reject","sra","use",
	"assert","constant","function","is","next","package","return","srl","variable",
	"attribute","disconnect","generate","label","nor","port","rol","subtype","wait",
	"begin","downto","generic","library","not","postponed","ror","then","when",
	"block","else","group","linkage","null","procedure","select","to","while",
	"body","elsif","guarded","literal","of","process","severity","transport","with",
	"buffer","end","if","loop","on","pure","signal","type","xnor",
	"bus","entity","impure","map","open","range","shared","unaffected","xor"
}
local ieeeheader=[=[
	library ieee;
	use ieee.std_logic_1164.all;
	use ieee.std_logic_unsigned.all;
	use ieee.numeric_std.all;
	use ieee.math_real.all;
]=]
local counter_for_unknown=0
local clean_name=function(name,letter)
	return "\\"..name:gsub("%s","_").."\\"
	-- letter=letter or "L"
	-- name=name:gsub("[^%d%w]","_"):gsub("^([^%u%l])",function(a)return letter.."_"..a end)
	-- if name=="" then
	-- 	name="anonymous_"..tostring(counter_for_unknown)
	-- 	counter_for_unknown=counter_for_unknown+1
	-- end
	-- if isIn(reserved_words,name) then
	-- 	return letter.."_"..name
	-- else
	-- 	return name
	-- end
end
local netName=function(net)
	if net<0 then
		return "null"
	else
		return "net_"..tostring(net)
	end
end
for uuid,circuit in pairs(circuits_by_id) do
	circuit.vhdl={}
	local name=clean_name(circuit.name,"c")
	if taken_names[name] then
		local num=2
		while taken_names[name.."_"..tostring(num)] do
			num=num+1
		end
		name=name.."_"..tostring(num)
	end
	taken_names[name]=uuid
	circuit.vhdl.name=name


	local first="entity "..name.." is\n"
	local last="\nend "..name..";"
	local pin_to_text=function(pin)
		local name="\t\t"..clean_name(pin.name,"p").." : "
		if pin.pintype=="input" then
			name=name.."in "
		else
			name=name.."out "
		end
		if pin.bitwidth==1 then
			name=name.."std_logic"
		else
			name=name.."std_logic_vector("..tostring(pin.bitwidth-1).." downto 0)"
		end
		return name
	end
	local pins={}
	for _,pin in ipairs(circuit.input) do
		table.insert(pins,pin_to_text(pin))
	end
	for _,pin in ipairs(circuit.output) do
		table.insert(pins,pin_to_text(pin))
	end
	if #pins>0 then
		pins="\tport(\n"..table.concat(pins,";\n").."\n\t);"
	else
		pins=""
	end
	local head=first..pins..last
	circuit.vhdl.head=head


	local arch="architecture behave of "..circuit.vhdl.name.." is\n"
	for i=1,#circuit.nets do
		arch=arch.."\tsignal "..netName(i).." : "
		local bitwidth=(circuit.nets[i].bitwidth or {})[1] or 1
		if bitwidth==1 then
			arch=arch.."std_logic;\n"
		else
			arch=arch.."std_logic_vector("..tostring(bitwidth-1).." downto 0);\n"
		end
	end
	arch=arch.."begin\n\n"
	
	for i,pin in ipairs(circuit.input) do
		arch=arch..netName(pin.net).." <= "..clean_name(pin.name,"p")..";\n"
	end
	arch=arch.."\n"
	for i,pin in ipairs(circuit.output) do
		arch=arch..clean_name(pin.name,"p").." <= "..netName(pin.net)..";\n"
	end
	arch=arch.."\n\n"


	for i,sym in ipairs(circuit.components.circuitsymbol or {}) do
		--serialize.prettyprint(sym)
		if classType(sym.component)=="gate" then
			local output=1
			for pos,pin in ipairs(sym.pins) do
				if pin.field[1]=="output" then
					output=pos
					break
				end
			end
			if sym.component.name:lower()=="not" then
				arch=arch..netName(sym.pins[output].net).." <= "..sym.component.name.." "..netName(sym.pins[(output)%2+1].net)..";\n"
			else
				arch=arch..netName(sym.pins[output].net).." <= "
				local concat={}
				for i,pin in ipairs(sym.pins) do
					if i~=output then
						if pin.net>=0 then
							table.insert(concat,netName(pin.net))
						end
					end
				end
				if sym.component.name:sub(1,1)=="N" then
					arch=arch.."NOT ("..table.concat(concat," "..sym.component.name:sub(2,-1).." ")..");\n"
				elseif sym.component.name=="XNOR" then
					arch=arch.."NOT ("..table.concat(concat," XOR ")..");\n"
				else
					arch=arch..table.concat(concat," "..sym.component.name.." ")..";\n"
				end
			end
		elseif classType(sym.component)=="memory" then
			if not sym.component.writeable then

			end
		elseif classType(sym.component)=="splitter" then
			local output=1
			for pos,pin in ipairs(sym.pins) do
				if pin.field[1]=="output" then
					output=pos
					break
				end
			end

			local pos=0
			for i,pin in ipairs(sym.pins) do
				if i~=output then
					if pin.bitwidth==1 then
						arch=arch..netName(sym.pins[output].net).."("..tostring(pos)..") <= "..netName(pin.net)..";\n"
					else
						arch=arch..netName(sym.pins[output].net).."("..tostring((pos+pin.bitwidth)-1).." downto "..tostring(pos)..") <= "..netName(pin.net)..";\n"
					end
					pos=pos+pin.bitwidth
				end
			end
		else
			if sym.pins then
				local name=clean_name(((circuits_by_id[sym.circuitid.str] or sym.component).name or "unknown"),"c")
				arch=arch.."\\i_"..tostring(i).."_"..name:sub(2,-2).."_"..classType(sym.component).."\\ : entity work."..name.."\n\tport map (\n"
				local portmap={}
				for i,pin in ipairs(sym.pins) do
					table.insert(portmap,"\t\t"..clean_name(pin.name,"p").." => "..netName(pin.net))
				end
				arch=arch..table.concat(portmap,",\n").."\n\t);\n"
			end
		end
	end



	arch=arch.."end behave;\n"
	circuit.vhdl.body=arch
end
for uuid,circuit in pairs(circuits_by_id) do
	local f=io.open(IF(outfolder~="",outfolder.."/","").."F_"..circuit.name:gsub("[^%d%u%l]","_")..".vhd","w")
	f:write(ieeeheader,"\n")
	f:write(circuit.vhdl.head)
	f:write(circuit.vhdl.body)
	f:close()
end


-- print("writing circuit.srzp")
-- io.open("circuit.srzp",     "w"):write(serialize.prettyencode(circuits_by_id))