

execute: lua export.lua "test.CircuitProject" "output"

as it does not infer flipflops replace "output/F_jk_flip_flop.vhd" with "F_jk_flip_flop_fix.vhd"


require lua 5.1
luajit is reccomended