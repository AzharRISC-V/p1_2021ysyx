--base,field,lists
--optional: class

local T=default(classType,type)

memoise=function(func)
	local data={}
	return function(...)
		local val=field.get(data,{...})
		if val~=nil then
			return table.unpack(val)
		else
			val=table.pack(func(...))
			field.set(data,{...},val)
			return table.unpack(val)
		end
	end
end

strict=function(enableCheck,types,func)
	if not enableCheck then
		return func
	end
	if T(types)~="table" then
		goto error
	end
	for i=1,#types do
		local Ti=T(types[i])
		if Ti=="table" then
			for k=1,#types[i] do
				if T(types[i][k])~="string" then
					goto error
				end
			end
		elseif Ti~="string" then
			goto error
		end
	end
	goto ret
	::error::
	error("type specifications must be table of strings",2)
	::ret::
	return function(...)
		local input={...}
		--local test={}
		--for i in ipairs(input) do
		--	test[i]=T(input[i])
		--end
		--print(table.concat(test," "))
		for i=1,#types do
			if types[i]~="any" then
				if type(types[i])=="table" then
					local valid=false
					local Tcheck=T(input[i])
					for k=1,#types[i] do
						if Tcheck==types[i][k] then
							valid=true
							break
						end
					end
					if not valid then
						error(table.concat{
							"argument #",i," was ",Tcheck," expected one of ",table.concat(types[i],"|")
						},2)
					end
				else
					if T(input[i])~=types[i] then
						error(table.concat{
							"argument #",i," was ",T(input[i])," expected ",types[i]
						},2)
					end
				end
			end
		end
		if #input>#types then
			print(table.concat{
				"got ",#input-#types, " extra arguments"
			})
		end
		return func(...)
	end
end
--[[
local L L=function(a,...)
	if select("#",...)>0 then
		return a,L(...)
	else
		return a
	end
end
--]]
Fun=function(func,...)
	local args={...}
	if T(func)~="function" then
		error("Fun must get at least a function")
	end
	return function(...)
		return func(table.unpack(lists.concat(args,{...})))
	end
end
--Fun(Fun,Fun,Fun,Fun,Fun,Fun,Fun,Fun,Fun,Fun,print,"hello world!")()()()()()()()()()()()
flags=function(flags)
	local keys,values={},{}
	local len=1
	for k,v in pairs(flags) do
		keys[len]=k
		values[len]=v
		len=len+1
	end
	return function(opts)
		if type(opts)~="table" then
			return flags
		end
		local newflag={}
		for i=1,len do
			newflag[keys[i]]=opts[keys[i]] or values[i]
		end
		return newflag
	end
end


safeflags=function(flags)
	local keys,values={},{}
	local len=1
	for k,v in pairs(flags) do
		keys[len]=k
		values[len]=v
		len=len+1
	end
	return function(opts)
		if type(opts)~="table" then
			return lists.sclone(flags)
		end
		local newflag={}
		for i=1,len do
			newflag[keys[i]]=default(opts[keys[i]],values[i])
		end
		return newflag
	end
end
--[[
dispatcher{
	[{"string","number"}]=function(name,value)
	end;
}
--]]
dispatcher=function(dict)
	local entries={}
	for types,func in pairs(dict) do
		local typelist={}
		for i,v in ipairs(types) do
			if T(v)~="string" then
				error("type definitions must be list of strings \""..tostring(v).."\"("..T(v)..") is not a string",2)
			end
			typelist[#typelist+1]=v
		end
		typelist[#typelist+1]=0
		if T(func)~="function" then
			error("["..table.concat(types,"|").."] must be a function",2)
		end
		field.set(entries,typelist,func)
	end
	return function(...)
		local typelist={}
		for i=1,select("#",...) do
			typelist[i]=T(select(i,...))
		end
		typelist[#typelist+1]=0
		local func=field.get(entries,typelist)
		if T(func)~="function" then
			error("["..table.concat(typelist,"|",1,#typelist-1).."]".." is not defined",2)
		end
		return func(...)
	end
end