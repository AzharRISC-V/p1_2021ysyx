--base

local triggerChar="\\"
local defaultChar="?"
local unescapeBehaviour="default"
local possibleUnescapeBehaviour={"ignore","error","remove","warning","default","return"}
local escapeCharacters={
	["\""]="\"";
	["n"]="\n";
	["t"]="\t";
	["b"]="\b";
	["'"]="\'";
	["r"]="\r";
}
string.defaultEscape={}
for i=0,31 do
	table.insert(string.defaultEscape,string.char(i))
end
for i=127,255 do
	table.insert(string.defaultEscape,string.char(i))
end
table.insert(string.defaultEscape,"\"")
table.insert(string.defaultEscape,"\'")
table.insert(string.defaultEscape,"\\")
for k,v in pairs(escapeCharacters) do
	table.insert(string.defaultEscape,v)
end
string.defaultEscape=table.concat(string.defaultEscape)


string.advStringLoaded=true

string.pad=function(str,length,filler)
	--str=default(str,tostring(str))
	filler=default(filler," ")
	if #str>length then
		str=string.sub(str,#str-length+1)
	elseif #str<length then
		str=string.rep(filler,length-#str)..str
	end
	return str
end

--these sets the properties of the functions
string.setUnescapeBehaviour=function(behaviour)
	--print("settnig",unescapeBehaviour)
	if isIn(possibleUnescapeBehaviour,behaviour) then
		unescapeBehaviour=behaviour
		return true
	else
		return false
	end
end

string.setDefaultChar=function(char)
	if type(char)=="string" then
		if #char<1 then
			return false
		else
			defaultChar=string.sub(char,1,1)
			return true
		end
	else
		return false
	end
end

string.setEscapeChar=function(char)
	if type(char)=="string" then
		if #char<1 then
			return false
		else
			triggerChar=string.sub(char,1,1)
			return true
		end
	else
		return false
	end
end

--these are actual functions

string.gbits=function(str)
	local bytepos,len,done,bits,bit,newByte=1,#str,false,{},false,false
	local makebits=function()
		local number=string.byte(str,bytepos)
		for i=1,8 do
			local remainder = number%2
			table.insert(bits,remainder>0)
			number = (number-remainder)/2
		end
		bytepos=bytepos+1
		done=bytepos>len
	end
	return function()
		newByte=#bits<1
		if #bits<1 then
			if done then return end
			makebits()
		end
		bit=bits[#bits]
		table.remove(bits)
		return bit,newByte
	end
end

string.gchars=function(inputString)
	if type(inputString)~="string" then
		error("string.gchars #1 must be a string",2)
	end
	
	local counter=0
	local maxCounter = #inputString

	return function()
		if counter<maxCounter then
			counter=counter+1
			return inputString:sub(counter,counter)
		end
	end
end

string.chars=function(str)
	if type(str)~="string" then
		error("string.chars #1 must be a string",2)
	end
	local t={}
	for c in string.gchars(str) do
		t[#t+1]=c
	end
	return t
end

string.gbytes=function(inputString)
	if type(inputString)~="string" then
		error("string.gbytes #1 must be a string",2)
	end
	local counter=0
	local maxCounter = #inputString

	return function()
		if counter<maxCounter then
			counter=counter+1
			return string.byte(inputString,counter)
		end
	end
end

string.bytes=function(str)
	if type(str)~="string" then
		error("string.bytes #1 must be a string",2)
	end
	local t={}
	for c in string.gbytes(str) do
		t[#t+1]=c
	end
	return t
end

string.replaceChar=function(instr,repl,chr)
	if type(instr)~="string" then
		error("string.replaceChar #1 must be string",2)
	end
	if type(repl)~="table" then
		error("string.replaceChar #2 must be table of strings",2)
	end
	if chr~=nil and type(chr)~="string" then
		error("string.replaceChar #3 must be string",2)
	end
	local str=""
	for c in string.gchars(instr) do
		if isIn(repl,c) then
			str=str..(chr or ".")
		else
			str=str..c
		end
	end
	return str
end

string.unescape=function(instr)
	--print("calling unescape")
	local warnings={}
	if type(instr)~="string" then
		error("string.unescape only works on strings",2)
	end

	local str={}
	local characters={}
	for c in string.gchars(instr) do
		characters[#characters+1]=c
	end
	local base16={
		["0"]=0,	["1"]=1,	["2"]=2,	["3"]=3,
		["4"]=4,	["5"]=5,	["6"]=6,	["7"]=7,
		["8"]=8,	["9"]=9,	["A"]=10,	["B"]=11,
		["C"]=12,	["D"]=13,	["E"]=14,	["F"]=15
	}

	local toReplace={}
	for i=0,31 do
		toReplace[#toReplace+1]=string.char(i)
	end
	for i=127,255 do
		toReplace[#toReplace+1]=string.char(i)
	end

	local i=1
	repeat

		if characters[i]==triggerChar and characters[i+1]==triggerChar then
			str[#str+1]=triggerChar
			i=i+2
		elseif characters[i]==triggerChar and escapeCharacters[characters[i+1]]~=nil then
			str[#str+1]=escapeCharacters[characters[i+1]]
			i=i+2
		elseif characters[i]==triggerChar then
			if #characters<i+2 or base16[characters[i+1]]==nil or base16[characters[i+2]]==nil then
				if unescapeBehaviour=="ignore" then
					str[#str+1]=characters[i]
					i=i+1

				elseif unescapeBehaviour=="default" then
					str[#str+1]=defaultChar
					i=i+3

				elseif unescapeBehaviour=="error" then

					error("\ninvalid escapeSequence @"..tostring(i).." \""..string.replaceChar(string.sub(instr,max{1,i-10},min{i+10,#instr}),toReplace).."\"\n"..
						string.rep(" ",#tostring(i)+24+min{i,11}).."<"..string.sub(instr,i,min{i+2,#instr})..">"
					,2)

				elseif unescapeBehaviour=="warning" then
					print("invalid escapeSequence @"..tostring(i).." \""..string.replaceChar(string.sub(instr,max{1,i-10},min{i+10,#instr}),toReplace).."\"\n"..
						string.rep(" ",#tostring(i)+24+min{i,11}).."<"..string.sub(instr,i,min{i+2,#instr})..">"
					)
					i=i+3

				elseif unescapeBehaviour=="return" then
					table.insert(warnings,"invalid escapeSequence @"..tostring(i).." \""..string.replaceChar(string.sub(instr,max{1,i-10},min{i+10,#instr}),toReplace).."\"\n"..
						string.rep(" ",#tostring(i)+24+min{i,11}).."<"..string.sub(instr,i,min{i+2,#instr})..">"
					)
					--print("akekeke",#warnings)
					str[#str+1]=defaultChar
					i=i+3

				elseif unescapeBehaviour=="remove" then
					i=i+3

				else
					error("invalid unescapeBehaviour:\""..tostring(unescapeBehaviour).."\"",2)
				end
			else
				str[#str+1]=string.char(base16[characters[i+1]]*16+base16[characters[i+2]])
				i=i+3
			end
		else
			--print("#####",str,characters[i],i,#characters)
			str[#str+1]=(characters[i] or "")
			i=i+1
		end
	until i>#characters
	--print(unescapeBehaviour,unescapeBehaviour=="return")
	if unescapeBehaviour=="return" then
		--print("returning warnings")
		return table.concat(str),warnings
	else
		return table.concat(str)
	end

end

string.escape=function(instr,toEscape,strict)
	--local triggerChar="%"
	if type(toEscape)=="string" then
		toEscape=toEscape:chars()
	elseif type(toEscape)=="table" then
		if #toEscape<1 then
			for i=0,32 do
				table.insert(toEscape,string.char(i))
			end
			for i=127,255 do
				table.insert(toEscape,string.char(i))
			end
		else
			for i=1,#toEscape do
				if type(toEscape[i])=="number" and toEscape[i]>=0 and toEscape[i]<=255 then
					toEscape[i]=string.char(toEscape[i])
				end
			end
		end
	else
		toEscape=string.defaultEscape:chars()
	end

	local base16={[0]="0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"}
	local escapeChar=function(char)
		--print(triggerChar,(string.byte(char,1)/16)%16,string.byte(char,1)%16)
		return triggerChar..base16[math.floor(string.byte(char,1)/16)%16]..base16[string.byte(char,1)%16]
	end
	local str={}
	for char in string.gchars(instr) do
		if not strict and char==triggerChar then
			str[#str+1]=char..char

		elseif (not strict) and isIn(toEscape,char) and isIn(escapeCharacters,char) then
			local _,index=isIn(escapeCharacters,char)
			str[#str+1]=triggerChar..index
		elseif isIn(toEscape,char) or char==triggerChar then
			str[#str+1]=escapeChar(char)
		else
			str[#str+1]=char
		end
	end
	return table.concat(str)
end


string.whitespace=string.unescape("\\09\\0A\\0B\\0C\\0D\\20"):chars()
string.stringDelimiter="\""



--untested
string.strip=function(str,removeRepeating,whiteSpace)
	removeRepeating=removeRepeating==true

	if type(whiteSpace)=="string" then
		whiteSpace=string.chars(whiteSpace)
	end
	if type(whiteSpace)~="table" then
		whiteSpace=string.whitespace
	end
	local chars=str:chars()
	for i=#chars,1,-1 do
		if isIn(whiteSpace,chars[i]) then
			table.remove(chars,i)
		else
			break
		end
	end
	for i=1,#chars do
		if isIn(whiteSpace,chars[1]) then
			table.remove(chars,1)
		else
			break
		end
	end
	if removeRepeating then
		for i=#chars,2,-1 do
			--print(i)
			if isIn(whiteSpace,chars[i]) and isIn(whiteSpace,chars[i-1]) then
				--print("removing",chars[i],i)
				table.remove(chars,i)
			end
		end
	end

	return table.concat(chars)
end

--untested
string.substitute=function(str,charset)
	if type(charset)=="string" then
		charset=string.chars(charset)
	end
	if type(charset)~="table" then
		return nil,"charset must be table or string"
	end
	local newstr=""
	for char in string.gchars(str) do
		local found,index=isIn(charset,char,true)--{["k"]="b";}
		if found then
			newstr=newstr..charset[index]
		else
			newstr=newstr..char
		end
	end
	return str
end
--untested
string.ffind=function(self,str,startAt,maxCount)
	if type(self)~="string" then
		return nil,"argument #1 must be string"
	end
	if type(maxCount)~="number" then
		maxCount=math.huge
	end
	if type(startAt)~="number" then
		startAt=1
	end

	if type(str)~="string" then
		str=tostring(str)
	end
	if #self<1 then--cant find anything if thera are nothing
		return {}
	end
	local first=string.sub(str,1,1)


	if startAt>#self then
		return nil,"out of bounds starting pos"
	end
	local pos={}
	local chars=string.chars(self)
	for i=startAt,#self do

		if chars[i]==first then
			if string.sub(self,i,i-1+#str)==str then
				table.insert(pos,i)

				if #pos>=maxCount then
					break
				end
			end
		end
	end

	return pos
end
--untested
string.splitAt=function(self,pos)

	if type(pos)=="number" then
		pos={pos}
	end
	if type(pos)~="table" then
		return nil,"pos must be number or table of numbers"
	else
		for i=1,#pos do
			if type(pos[i])~="number" then
				return nil,"pos must only contain numbers"
			end
		end
	end
	if #pos<1 then
		return {self}
	end

	table.sort(pos)
	--removing dupliates
	for i=#pos,2,-1 do
		if pos[i]==pos[i-1] or pos[i]>#self then
			table.remove(pos,i)
		end
	end

	local splits={}
	local tpos=1
	for i=1,#pos do
		table.insert(splits,string.sub(self,tpos,pos[i]-1))
		tpos=pos[i]
	end
	local substr,err=string.sub(self,pos[#pos],#self)
	if err~=nil then
		return nil,err
	end
	table.insert(splits,string.sub(self,pos[#pos],#self))
	return splits
end;

--untested
string.replace=function(self,target,data)

	if type(target)~="string" then
		return nil,"target must be string"
	end

	if type(data)~="string" then
		return nil,"data must be string"
	end


	--target=advString(target)
	local pos,err=string.ffind(self,target)
	if err~=nil then
		return nil,err
	end
	if #pos<1 then
		return nil,"no occurances found"
	end
	------------------------------------------------------
	local splits=string.splitAt(self,pos)

	for i=1,#splits do
		if string.sub(splits[i],1,#target)==target then
			splits[i]=data..string.sub(splits[i],#target,-1)
		end
	end

	return table.concat(splits)
end

--untested
string.split=function(self,points,doRepeat,include)


	doRepeat=(doRepeat or true)==true-- false or true == true completely meaningless
	--[[
		true 	-> true
		false 	-> true
		nil 	-> true
		0 		-> false
		{} 		-> false
	--]]
	if type(self)~="string" then
		return nil,"arg #1 must be string"
	end
	if type(points)=="string" then
		points={points}
	end
	if type(points)~="table" then
		--print("a")
		return nil,"points must be string or table of strings"
	else
		for i=1,#points do
			if type(points[i])~="string" then
				return nil,"points must be string or table of strings"
			end
		end
	end

	local pos=1
	local splits={1}
	repeat
		for i=1,#points do
			local tPos=string.ffind(self,points[i],pos,1)
			if tPos~=nil then
				tPos=tPos[1]
			end
			if tPos==nil then
				pos=math.huge
				break
			else
				table.insert(splits,tPos)
				pos=tPos+#points[i]--
			end
			if pos>#self then
				break
			end
		end
	until (not doRepeat) or pos>#self
	local stringSplits={}
	for i=1,#splits-1 do
		table.insert(stringSplits,string.sub(self,splits[i]+IF(include==true and i>1,1,0),splits[i+1]-1))
	end
	table.insert(stringSplits,string.sub(self,splits[#splits]+IF(include==true and #splits>1,1,0),#self))


	return stringSplits
end

string.random=function(length)
	if type(length)~="number" then
		length=1
	end
	local str={}
	for i=1,length do
		str[#str+1]=string.char(math.random(0,255))
	end
	return table.concat(str)
end
string.SPAic=("\\9ASPAic"):unescape()
local base64Charset="[A-Za-z0-9%+%/]"
local b="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B,B_={},{}
for i=1,#b do
	B[i-1]=b:sub(i,i)
	B_[b:sub(i,i)]=i-1
end

local bytes_to_hexes=function(str)
	local b1,b2,b3=str:byte(1)or 0,str:byte(2)or 0,str:byte(3)or 0
	local h1,h2,h3,h4
	local len=#str
	if len==3 then
		h1=math.floor(b1/4)
		h2=(b1-h1*4)*16+math.floor(b2/16)
		h3=((b2%16)*4)+math.floor(b3/64)
		h4=b3%64
		return B[h1]..B[h2]..B[h3]..B[h4]
	elseif len==2 then
		h1=math.floor(b1/4)
		h2=(b1-h1*4)*16+math.floor(b2/16)
		h3=((b2%16)*4)
		return B[h1]..B[h2]..B[h3].."="
	else
		h1=math.floor(b1/4)
		h2=(b1-h1*4)*16
		return B[h1]..B[h2].."=="
	end
end
local hexes_to_bytes=function(str)
	local h1,h2,h3,h4=str:sub(1,1),str:sub(2,2),str:sub(3,3),str:sub(4,4)
	--serialize.prettyprint({h1,h2,h3,h4})
	local b1,b2,b3,bh2,bh3
	local len=#str
	if h3=="=" then--1 byte
		b1=B_[h1]*4+math.floor(B_[h2]/16)
		return string.char(b1)
	elseif h4=="=" then--2 bytes
		bh2=B_[h2]
		b1=B_[h1]*4+math.floor(bh2/16)
		b2=(bh2%16)*16+math.floor(B_[h3]/4)
		return string.char(b1)..string.char(b2)
	else--3 bytes
		bh2,bh3=B_[h2],B_[h3]
		b1=B_[h1]*4+math.floor(bh2/16)
		b2=(bh2%16)*16+math.floor(bh3/4)
		b3=(bh3%4)*64+B_[h4]
		return string.char(b1)..string.char(b2)..string.char(b3)
	end
end
string.tobase64=function(str)
	return (str:gsub("..?.?",bytes_to_hexes))
end
string.frombase64=function(str)
	return (str:gsub("..?.?.?",hexes_to_bytes))
end

string.afmt=function(str,data)
	data=data or _G
	return (str:gsub("%$%b{}",function(str)
		--print(str)
		local D=field.get(data,field.read(str:sub(3,-2)))
		if type(D)=="function" then
			D=D()
		end
		return default(serialize.prettyencodeflat,tostring)(D)
	end))
end
string.sfmt=function(str,data)
	data=data or _G
	return (str:gsub("%$%b{}",function(str)
		--print(str)
		local D=field.get(data,field.read(str:sub(3,-2)))
		if type(D)=="function" then
			D=D()
		end
		if type(D)=="string" then
			return D
		else
			return serialize.prettyencode(D)
		end
	end))
end

