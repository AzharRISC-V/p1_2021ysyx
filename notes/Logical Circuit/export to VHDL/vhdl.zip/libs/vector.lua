local cos,sin,sqrt,floor,atan2=math.cos,math.sin,math.sqrt,math.floor,math.atan2


local vector
local new_polar_vector = function(size, angle)
	local x=size * cos(angle)
	local y=size * sin(angle)

	return vector(x,y)
end
local T=default(classType,type)
local typeCheck=true
vector=class{"vector";
	constructor=strict(typeCheck,{{"number","bigint"},{"number","bigint"}},function(x,y)
		return {x=x,y=y}
	end);
	variables={x=0,y=0};
	serialize=function(self)
		return {self.x,self.y}
	end;
	unserialize=function(data)
		return {x=data[1],y=data[2]}
	end;
	common={
		size = function(self)
			return sqrt(self.x^2 + self.y^2)
		end;
		floor = function(self)
			return vector(floor(self.x),floor(self.y))
		end;
		round = function(self)
			return vector(floor(self.x+0.5),floor(self.y+0.5))
		end;
		clamp = function(self,min,max)
			local maxx=0
			local maxy=0
			local minx,miny
			if min.x>max.x then
				maxx,minx=min.x,max.x
			else
				maxx,minx=max.x,min.x
			end
			if min.y>max.y then
				maxy,miny=min.y,max.y
			else
				maxy,miny=max.y,min.y
			end

			local x=self.x
			if x<minx then
				x=minx
			elseif x>maxx then
				x=maxx
			end
			local y=self.y
			if y<miny then
				y=miny
			elseif y>maxy then
				y=maxy
			end
			return vector(x,y)
		end;

		rotate = function(self,deg)
			return new_polar_vector(self:size(),self:angle()+deg)
		end;

		angle = function(self)
			return atan2(self.y,self.x)
		end;

		setSize = function(self,x,y)
			self.x = x
			self.y = y
		end;

		setAngle = function(self,rad)
			return new_polar_vector(self:size(),rad)
		end;

		setLenght = function(self,lenght)
			return new_polar_vector(lenght,self:angle())
		end;

		dot = function(self,other)
			return self.x * other.x + self.y * other.y
		end;

		cross = function(self,other)
			return self.x * other.y - self.y * other.x
		end;
	};
	metatable={
		__index = function(self,index)
			if index=="x" then
				return self.x
			end
			if index=="y" then
				return self.y
			end
			if index=="xy" then
				return self.x,self.y
			end
			if index=="yx" then
				return self.y,self.x
			end
			error("vector does not contain " .. tostring(index),2)
		end;

		__newindex = function(self,key,value)
			error("cannot set new index " .. tostring(key) .. " to " .. tostring(value),2)
		end;

		
		--comp
		__eq  = function(self,other)		return T(self)==T(other) and self.x == other.x and self.y == other.y end;
		__lt  = function(self,other)		return self:size() < other:size() end;
		__le  = function(self,other)		return self:size() <= other:size() end;
		--math
		__len = function(self) 			return self:size() end,
		__add = function(self,other) 	return vector(self.x+other.x,self.y+other.y) end;
		__sub = function(self,other) 	return vector(self.x-other.x,self.y-other.y) end;
		__unm = function(self) 			return vector(-self.x,-self.y) end;
		__mul = function(self,other)
			if T(self)=="number" then 
				return vector(self*other.x,self*other.y)
			elseif T(other)=="number" then 
				return vector(self.x*other,self.y*other) 
			else
				return vector(self.x*other.y,self.y*other.x) 
			end
		end;
		__div = function(self,other)
			if T(self)=="number" then
				return vector(self/other.x,self/other.y)
			elseif T(other)=="number" then
				return vector(self.x/other,self.y/other)
			else
				return vector(self.x/other.y,self.y/other.x)
			end
		end;
		__mod = function(self,other) 	return vector(self.x%other.x,self.y%other.y) end;
		--util
		__call = function(self,...)		return self.x,self.y,...	end;
		__concat = function(self,other) return tostring(self) .. tostring(other) end;
		__tostring = function(self)		return "[" .. tostring(self.x) .. "," .. tostring(self.y) .. "]" end;
		__info=[[is an implementation of a 2d vector.
It has mathods for several useful evaluations, as well as all the mathemathical metamethods.
vector:
	x:${x}
	y:${y}]];
	};
}

_G.vector=vector
_G.polarvector=new_polar_vector