
IF=function(condition,isTrue,isFalse)
	if condition then
		return isTrue
	else
		return isFalse
	end
end

assert_R=assert
assert=function(test,msg,lvl)
	if not test then
		error(msg or "assertion failed!",(lvl or 1)+1)
	end
end
if coroutine then
	coroutine.maybeyield=function(...)
		if coroutine.isyieldable() then
			return coroutine.yield(...)
		else
			return ...
		end
	end
end

default=function(variable,Type,default)
	if default==nil then
		default=Type
		Type=type(default)
	end
	local var_type=type(variable)
	if Type==var_type then
		return variable
	else
		return default
	end
end

clamp=function(min,val,max)
	val=val or min
	if val<min then
		return min
	elseif val>max then
		return max
	else
		return val
	end
end

max=function(a)
	local nMax=-math.huge
	local index=0
	for i=1,#a do
		if type(a[i])=="number" and a[i]>nMax then
			nMax=a[i]
			index=i
		end
	end
	return nMax,index
end

min=function(a)
	local nMin=math.huge
	local index=0
	for i=1,#a do
		if type(a[i])=="number" and a[i]<nMin then
			nMin=a[i]
			index=i
		end
	end
	return nMin,index
end

round=function(val,prec)
	if type(prec)~="number" then
		prec=1
	end
	return math.floor((val/prec)+0.5)*prec
end

isIn=function(list,item,fun)
	if type(list)~="table" then
		return false
	end
	if type(fun)=="function" then
		for index,value in pairs(list) do
			if fun(value,item) then
				return true,index
			end
		end
	else
		for index,value in pairs(list) do
			if value==item then
				return true,index
			end
		end
	end
	return false,nil
end
local errorfunc=function(s,index)error("ERROR: unable to create new index _G["..tostring(index).."]")end
lock_G=function()
	local G=default(getmetatable(_G),{})
	G.__newindex=errorfunc
	setmetatable(_G,G)
end
unlock_G=function()
	local G=default(getmetatable(_G),{})
	G.__newindex=nil
	setmetatable(_G,G)
end

if type(math)=="table" then
	math.truck_to_zero=function(num)
		return default(num<0,math.ceil,math.floor)(num)
	end
end

