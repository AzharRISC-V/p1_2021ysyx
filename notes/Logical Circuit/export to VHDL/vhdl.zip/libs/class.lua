--base,lists,serialize

local pack=pack or table.pack or function(...)return{...}end
local unpack=unpack or table.unpack


local rawType=type
classType = function(object)
	local objectType=rawType(object)
	if objectType == "table" then
		local mt=getmetatable(object)
		if mt~=nil --[[and mt.__isclass]] then
			return default(mt.__type,objectType)
		else
			return objectType
		end
	else
		return objectType
	end
end


--simple creator for classes
local registeredClasses=setmetatable({},{
--	__index=function(self,index)
--		for i=1,#self do
--			if index==self[i].name then
--				return self[i]
--			end
--		end
--		return nil
--	end;
})
getRegisteredClasses=function(name)
	if type(name)=="string" then
		return registeredClasses[name]
	else
		return registeredClasses
	end
end
registerClass=(strict or function(a,b,c)return c end)(true,
	{"string","function",{"nil","function"},{"nil","function"},{"nil","table"}},
	function(name,constructor,serialize,unserialize,metatable)
	if not registeredClasses[name] then
		registeredClasses[name]={
			name=name,
			constructor=constructor,
			serialize=serialize or function()
				error("cannot serialize "..name)
			end,
			unserialize=unserialize or function()
				error("cannot unserialize "..name)
			end,
			metatable=metatable or {},
		}
		return true
	else
		return false
	end
end)




serializeclass=function(instance)
	local name=classType(instance)
	local constr=registeredClasses[name]
	if type(constr)~="table" then
		return nil,"Attempting to serialize class of type("..tostring(name)..") which is undefined"
	end
	return {name,constr.serialize(instance)}
end

unserializeclass=function(tab)
	local constr=registeredClasses[tab[1]]

	if type(constr)~="table" then
		return nil,"Attempting to unserialize class of type("..tostring(tab[1])..") which is undefined"
	end
	local instance=constr.unserialize(tab[2])
	return instance
end




local classNumber=0

local example=[=[--lua

template=class{"template";--name of class
	constructor=function(a,b)
		
		return {},--base data for class
			abc,def --parameters for postmod
	end;
	postmod=function(self,abc,def)
		self.kve=def
		return self.kve--returned from constructor
	end;
	serialize=function(self)
		return {}--data for serialization
		--by default this is all in variables
	end;
	unserialize=function(tab)
		return self--gets the same data as __serialize returns as input
		--returns same as constructor
		--postmod is also called from unserialize
	end;
	variables={
		--copies made for each instance
		--default serializer treats this as important values
		--and serialize these values
	};
	common={
		--accessable by all instances
		--read only
	};
	metatable={
	};
}

template_instance=template(a,b)
--lua]=]


class=function(parameters)
	if type(parameters)=="string" then
		--error("using the class function as instantiating tool is depreciated.",2)
		local classI=getRegisteredClasses(parameters)
		if classI then
			return classI.constructor
		else
			error(parameters.." does not exist",2)
		end
	end
	if type(parameters)~="table" then
		return nil,"A description of the class is needed to create a constructor."
	end
	if parameters.type==nil then
		parameters.type=parameters[1]
	end



	local _type=default(parameters.type,"class#"..tostring(classNumber))
	local variables=default(parameters.variables,{})
	local common=default(parameters.common,{})
	local metatable=default(parameters.metatable,{})
	local constructor=default(parameters.constructor,function(...)return...end)

	if registeredClasses[_type]~=nil then
		--error(_type.." is already defined. Use that or change the name.",2)
		return registeredClasses[_type].constructor,_type.." is already defined. Use that or change the name."
	end

	classNumber=classNumber+1
	--print("classNumber:",classNumber,_type)
	metatable.__type=_type
	metatable.__isclass=true



	local importantFields={}
	for k,v in pairs(variables) do
		table.insert(importantFields,k)
	end


	local postmod=default(parameters.finalizer,function(self) end)
	--postmod=default(parameters.postmod,postmod)
	
	local metaIndex=metatable.__index
	if isIn({"table","function"},type(metaIndex)) then
		metatable.__index=setmetatable(common,{__index=metaIndex})
	else
		metatable.__index=setmetatable(common,{__index=function()return metaIndex end})
	end

	local simpleConstruction=function(constrParameters,postMod)
		local postModification=default(postMod,{})
		
		constrParameters=default(constrParameters,{})

		local newClass=lists.clone(constrParameters)
		
		lists.merge(newClass,lists.clone(variables))
		--for k,v in pairs(variables) do
		--	if newClass[k]==nil then
		--		newClass[k]=v
		--	end
		--end

		setmetatable(newClass,metatable)
		local toreturn=pack(postmod(newClass,unpack(postModification)))
		return newClass,unpack(toreturn)
	end

	local newClassConstructor=function(constrParameters,...)
		local postModification

		postModification=pack(constructor(constrParameters,...))
		
		local newConstrParameters=postModification[1]
		table.remove(postModification,1)

		constrParameters=default(
			newConstrParameters,
			"table",
			constrParameters
		)
		
		return simpleConstruction(constrParameters,postModification)
	end

	local serializer
	if parameters.serialize==false then
		serializer=function(self)
			error(classType(self).." cannot be serialized")
		end
	else
		serializer=default(parameters.serialize,function(self)
			local tab={}
			for i=1,#importantFields do
				tab[importantFields[i]]=rawget(self,importantFields[i])
			end
			return tab
		end)
	end
	local partialunserializer=default(parameters.unserialize,function(tab)
		local instance={}
		for i=1,#importantFields do
			instance[importantFields[i]]=tab[importantFields[i]]
		end
		return instance
	end)
	local unserializer
	if parameters.unserialize==false then
		unserializer=function(self)
			error(classType(self).." cannot be unserialized")
		end
	else
		unserializer=function(tab)
			local data=pack(partialunserializer(tab))
			local instance=data[1]
			table.remove(data,1)
			return simpleConstruction(instance,data)
		end
	end



	registerClass(_type,newClassConstructor,serializer,unserializer)
	return newClassConstructor
end


struct=function(name,vars)
	local tab={name,
		variables=vars
	}
	tab.metatable={
		__isstruct=true;
		__index=function(self,index)
			error(classType(self).." does not contain "..tostring(index),2)
		end;
		__newindex=function(self,index)
			error(classType(self).." does not contain "..tostring(index).." and it cannot be created",2)
		end;
	}
	if vars==nil then
		return function(vars)
			tab.variables=vars
			return class(tab)
		end
	else
		return class(tab)
	end
end
example=[=[--lua
	test=struct("test",{numer=0,name="test"})
	test2=struct"test2"{numer=3,name="test2"}

	test_instance=test{numer=1,name="george"}
	test2_instance=test2{numer=1,name="george"}
--lua]=]

hollow_class=function(name)
	return class{name,
		serialize=function(self)
			return lists.copy(self)
		end;
		unserialize=function(self)
			return self
		end;
	}
end


isclass=function(inst)
	local M=default(getmetatable(inst),{})
	return M.__isclass==true,M.__type
end
isstruct=function(inst)
	local M=default(getmetatable(inst),{})
	return (M.__isclass and M.__isstruct) or false,M.__type
end
local new=function(name)
	local classI=getRegisteredClasses(name)
	if classI then
		return classI.constructor
	else
		error(parameters.." does not exist",2)
	end
end