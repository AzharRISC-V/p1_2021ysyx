--base,field,
--optional: 


lists=setmetatable({},{__type="api"})

local clone,copy
clone=function(_table,lim)
	if type(lim)~="number" then
		lim=math.huge
	end
	if lim<=0 then
		return {}
	end
	local newTable={}
	for key,value in pairs(_table) do
		if type(value)=="table" then
			newTable[key]=clone(value,lim-1)
		else
			newTable[key]=value
		end
	end
	if getmetatable(_table)~=nil then
		return setmetatable(newTable,getmetatable(_table))
	else
		return newTable
	end
end
local sclone
sclone=function(_table,lim)
	if type(lim)~="number" then
		lim=math.huge
	end
	if lim<=0 then
		return {}
	end
	local newTable={}
	for key,value in pairs(_table) do
		if type(value)=="table" then
			newTable[key]=sclone(value,lim-1)
		else
			newTable[key]=value
		end
	end
	return newTable
end
local merge
merge=function(t1,t2,recursive)
	t1=t1 or {}
	t2=t2 or {}
	for i=1,#t2 do
		table.insert(t1,t2[i])
	end
	for key,value in pairs(t2) do
		if not (type(key)=="number" and key>=1 and key<=#t2) then
			--this can potentialy duplicate values from t2
			if t1[key]==nil then
				t1[key]=t2[key]
			elseif recursive and type(t1[key])=="table" and type(t2[key])=="table" then
				t1[key]=merge(t1[key],t2[key])
			end
		end
	end
	return t1
end

local reverse=function(list)
	local newList={}
	local pos=1
	for i=#list,1,-1 do
		newList[pos]=list[i]
		pos=pos+1
	end
	return newList
end
local lmod=function(list,index)
	return (index-1)%#list+1
end

local flatten
flatten=function(list,accumulator)
	accumulator=accumulator or {}
	for i=1,#list do
		if type(list[i])=="table" then
			flatten(list[i],accumulator)
		else
			accumulator[#accumulator+1]=list[i]
		end
	end
	return accumulator
end

local encodeStructure
encodeStructure=function(list)
	local str={"{"}
	local num=0
	for i=1,#list do
		if type(list[i])=="table" then
			if num>=1 then
				str[#str+1]=num
			end
			num=0
			str[#str+1]=encodeStructure(list[i])
		else
			num=num+1
		end
	end
	if num>=1 then
		str[#str+1]=num
	end
	str[#str+1]="}"
	return table.concat(str)
end


local unflat=function(list)
	local unflat={}
	local field,pointer={1},2
	local structure=list[1]
	local nums,numpoint={},1
	local shape=string.gsub(structure,"(%d+)",function(num)
		nums[#nums+1]=num
		return "!"
	end)

	string.gsub(shape,".",function(char)
		if char=="{" then
			field.set(unflat,field,{})
			field[#field+1]=1
		elseif char=="}" then
			table.remove(field)
			field[#field]=field[#field]+1
		elseif char=="!" then
			local count=nums[numpoint]
			numpoint=numpoint+1
			for i=1,count do
				field.set(unflat,field,list[pointer])
				field[#field]=field[#field]+1
				pointer=pointer+1
			end
		else
		end
	end)
	
	return unflat[1]
end
local flat
flat=function(list)
	local flat=flatten(list)
	table.insert(flat,1,encodeStructure(list))
	return flat
end

local linearize,unlinearize
linearize=function(list,lim)
	local lim = default(lim,math.huge)
	if lim<=0 then
		return list
	end
	local newTable={0}
	--table.insert(newTable,#list)
	local last=0
	for i in ipairs(list) do
		if type(list[i])=="table" then
			newTable[i+1]=linearize(list[i],lim-1)
		else
			newTable[i+1]=list[i]
		end
		last=max{last,i}
	end
	newTable[1]=last
	for k,v in pairs(list) do
		if type(k)=="number" and k>=1 and k<=last then
		else
			if type(k)=="table" then
				k=linearize(k,lim-1)
			end
			if type(v)=="table" then
				v=linearize(v,lim-1)
			end
			newTable[#newTable+1]=k
			newTable[#newTable+1]=v
		end
	end
	return newTable
end
unlinearize=function(list,lim)
	local lim = default(lim,math.huge)
	if lim<=0 then
		return list
	end
	local newTable,len={},1
	--odebug.print(list)
	local lenght=list[1]--default(list[1],#list)
	local pos=1
	for i=2,1+lenght do
		if type(list[i])=="table" then
			newTable[pos]=unlinearize(list[i],lim-1)
		else
			newTable[pos]=list[i]
		end
		pos=pos+1
	end
	for i=lenght+2,#list,2 do
		local k,v=list[i],list[i+1]
		if type(k)=="table" then
			k=unlinearize(k,lim-1)
		end
		if type(v)=="table" then
			v=unlinearize(v,lim-1)
		end
		--print(type(k))
		if type(k)~="nil" then
			newTable[k]=v
		end
	end
	return newTable
end
local unlinearizeOnce=function(list)
	local newTable,len={},1
	local lenght=list[1] or 0
	local pos=1
	for i=2,1+lenght do
		newTable[pos]=list[i]
		pos=pos+1
	end
	for i=lenght+2,#list,2 do
		local k=list[i]
		--print(type(k))
		if k~="nil" then
			newTable[k]=list[i+1]
		end
	end
	return newTable
end

local compare
compare=function(list1,list2,lim)
	lim=default(lim,math.huge)

	if lim<=0 then
		return true
	end
	if list1==list2 then--naive testing
		return true
	end
	for key in pairs(list1) do

	end
end

local isLinear=function(list)
	local len=#list
	for k in pairs(list) do
		if type(k)~="number" or k<1 or k>len then
			return false
		end
	end
	return true
end
local isFlat=function(list)
	for k,v in pairs(list) do
		if type(v)=="table" then
			return false
		end
	end
	return true
end
local removeDuplicates=function(list)
	local found={}
	local newList={}
	for i,v in ipairs(list) do
		if not found[v] then
			newList[#newList+1]=v
			found[v]=true
		end
	end
	return newList
end

local concat=function(...)
	local input={...}
	local newList={}
	for _,l in ipairs(input)do 
		for _,v in ipairs(l) do
			newList[#newList+1]=v
		end
	end
	return newList
end

local len=7
local order={
	["boolean"]=1,
	["number"]=2,
	["string"]=3,
	["nil"]=4,
	["api"]=5,
	["table"]=6,
}
local comps=setmetatable({
	["boolean"]=function(a,b)
		return not a and b
	end;
	["number"]=function(a,b)
		return a<b
	end;
	["string"]=function(a,b)
		local numa=tonumber(a:match("%d+$"))
		local numb=tonumber(b:match("%d+$"))
		if tonumber(numa)~=nil and tonumber(numb)~=nil and #a==#b then
			return tonumber(numa)<tonumber(numb)
		end
		for i=1,min{#a,#b} do
			if string.byte(a,i)~=string.byte(b,i) then
				return string.byte(a,i)<string.byte(b,i)
			end
		end
		return #a<#b
	end;
	["nil"]=function(a,b)
		return true
	end;
	["table"]=function(a,b)
		return #a<#b
	end;
},{__index=function(self,index)
	return function(a,b)
		return self["string"](tostring(a),tostring(b))
	end
end})

local superComp=function(a,b)
	local Ta=type(a)
	local Tb=type(b)
	local iA=order[Ta]
	if iA==nil then
		iA=len
		order[Ta]=iA
		len=len+1
	end
	local iB=order[Tb]
	if iB==nil then
		iB=len
		order[Ta]=iB
		len=len+1
	end
	if iA==iB then
		return comps[Ta](a,b)
	else
		return iA<iB
	end
end


local orderedPairs=function(list)
	local index=0
	local orderedIndex = {}
	for key,value in pairs(list) do
		orderedIndex[#orderedIndex+1]=key 
	end
	table.sort(orderedIndex,superComp)

	return function()
		index=index+1
		if index<=#orderedIndex then
			return orderedIndex[index],list[orderedIndex[index]]
		else
			return nil
		end
	end
end
local randomPairs=function(list)
	local unorderedIndex = {}
	for key,value in pairs(list) do
		unorderedIndex[#unorderedIndex+1]=key 
	end
	return function()
		local index=math.random(1,#unorderedIndex)
		if #unorderedIndex>0 then
			local key=unorderedIndex[index]
			local value=list[key]
			table.remove(unorderedIndex,index)
			return key,value
		else
			return nil
		end
	end
end
copy=function(list)
	if type(list)~="table" then
		return list
	end
	local newList={}
	for k,v in pairs(list) do
		newList[k]=v
	end
	return newList
end

local map=function(list,func)
	local result={}
	if type(map)=="function" then
		for k,v in ipairs(list) do
			result[k]=func(v)
		end
	elseif type(func)=="table" then
		for k,v in ipairs(list) do
			result[k]=func[v]
		end
	else
		return nil,"func must be table or function"
	end
	return result
end

local defaultReduse=function(i,v,acc)
	if acc~=nil then
		return tostring(acc).."+["..tostring(i).."|"..tostring(v).."]"
	else
		return "["..tostring(i).."|"..tostring(v).."]"
	end
end

local reduce=function(list,func)
	local acc
	func=default(func,defaultReduse)
	for i,v in ipairs(list) do
		acc=func(i,v,acc)
	end
	return acc
end

--[[Exposed functions belove here]]--

lists.sort=function(list,func)
	local newList=copy(list)
	table.sort(newList, default(func,superComp))
	return newList
end
lists.sub=function(list,start,stop)
	start=default(start,1)
	stop=default(stop,#list)
	
	local newList={}
	local step=1
	
	if stop<start then
		step=-1
	end

	for i=start,stop,step do
		newList[#newList+1]=list[i]
	end
	return newList
end

lists.isIn=function(list,item,fun)
	if type(list)~="table" then
		return false,nil
	end
	if type(fun)=="function" then
		local found,foundIndex
		for index,value in pairs(list) do
			found,foundIndex=fun(value,index,item)
			if found then
				return true,foundIndex
			end
		end
	else
		for index,value in pairs(list) do
			if value==item then
				return true,index
			end
		end
	end
	return false,nil
end

lists.orderedPairs		=orderedPairs
lists.randomPairs		=randomPairs
lists.removeDuplicates	=removeDuplicates
lists.encodeStructure	=encodeStructure
lists.flatten			=flatten
lists.unflat			=unflat
lists.flat				=flat
lists.merge				=merge
lists.reverse			=reverse
lists.lmod				=lmod
lists.concat			=concat
lists.clone				=clone
lists.sclone			=sclone
lists.copy				=copy
lists.linearize			=linearize
lists.unlinearize		=unlinearize
lists.unlinearizeOnce	=unlinearizeOnce

lists.map				=map
lists.reduce			=reduce


lists.isLinear=isLinear
lists.isFlat=isFlat
lists.insert=function(tab,pos,data)
	table.insert(tab,pos,data)
	return tab
end
lists.pack=function(list)
	return flat(linearize(list))
end
lists.unpack=function(list)
	return unlinearize(unflat(list))
end
